<?php 
	/*
	*
	*
	*/
	class Usuario{
		private $NombreC;
		private $contrasena;

		// public function getId(){
		// 	return $this->id;
		// }

		// public function setId($id){
		// 	$this->id = $Id;
		// }

		public function getNombre(){
			return $this->nombre;
		}

		public function setNombre($nombre){
			$this->nombre = $NombreC;
		}

		public function getClave(){
			return $this->contrasena;
		}

		public function setClave($clave){
			$this->clave = $contrasena;
		}
	}
?>